# app.py – Robô Marce: Análise técnica para Quartos/Acompanhar no celular
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import requests

st.set_page_config(page_title="Robô Marce", layout="wide")
st.title("🤖 Robô Marce – Análise Gráfica (Mobile)")

symbols = {"EUR/USD":"EUR/USD","GBP/USD":"GBP/USD","AUD/CAD":"AUD/CAD","USD/JPY":"USD/JPY"}
symbol = st.selectbox("Selecione o par de moedas:", list(symbols.keys()))

api_key = "54626e0988c64f788c0ad00fe8e442e"
interval = "1min"
url = f"https://api.twelvedata.com/time_series?symbol={symbols[symbol]}&interval={interval}&outputsize=100&apikey={api_key}"

response = requests.get(url).json()
if response.get("status") == "error":
    st.error(f"Erro na API: {response.get('message')}")
else:
    df = pd.DataFrame(response["values"])
    df["datetime"] = pd.to_datetime(df["datetime"])
    df = df.sort_values("datetime")
    df[["open","high","low","close"]] = df[["open","high","low","close"]].astype(float)

    delta = df["close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    rs = avg_gain / avg_loss
    df["RSI"] = 100 - (100 / (1 + rs))

    df["SMA20"] = df["close"].rolling(window=20).mean()
    df["EMA10"] = df["close"].ewm(span=10, adjust=False).mean()

    fig = go.Figure()
    fig.add_trace(go.Candlestick(x=df["datetime"], open=df["open"],
                                 high=df["high"], low=df["low"],
                                 close=df["close"], name="Velas"))
    fig.add_trace(go.Scatter(x=df["datetime"], y=df["SMA20"],
                             line=dict(color="blue", width=1), name="SMA 20"))
    fig.add_trace(go.Scatter(x=df["datetime"], y=df["EMA10"],
                             line=dict(color="orange", width=1), name="EMA 10"))
    fig.update_layout(title=f"📊 Robô Marce – {symbol}", xaxis_rangeslider_visible=False)
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("📉 RSI (Índice de Força Relativa)")
    st.line_chart(df.set_index("datetime")["RSI"])

    st.subheader("📢 SINAL ATUAL")
    rsi_now = df["RSI"].iloc[-1]
    if rsi_now < 30:
        st.success("🔼 CALL (RSI < 30 – mercado sobrevendido)")
    elif rsi_now > 70:
        st.error("🔽 PUT (RSI > 70 – mercado sobrecomprado)")
    else:
        st.info("⏳ Neutro – aguardando confirmação")