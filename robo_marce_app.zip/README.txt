# Robô Marce – Análise de Opções Binárias (Mobile)

## ✅ Como usar:
1. Vá para https://github.com/new e crie um repositório público chamado `robo-marce`
2. Envie os arquivos `app.py` e `requirements.txt` para lá
3. Acesse https://streamlit.io/cloud e clique em "New app"
4. Conecte com GitHub, selecione `robo-marce`, arquivo `app.py` e clique em Deploy
5. Acesse no seu celular o link gerado: https://robo-marce.streamlit.app

Depois, clique em “Adicionar à tela inicial” no navegador para usar como app.

✅ Indicadores:
- Velas japonesas
- Média móvel simples (SMA 20)
- Média móvel exponencial (EMA 10)
- RSI (Índice de Força Relativa) com alertas automáticos